% Nahodne hladanie minima Rastrigin funkcie
%==================================================

numcykle=1000;	% pocet cyklov hladania
lpop=30;        % velkost  populacie - kolko retazcov naraz testujem

Space=[ones(1,10)*(-5);ones(1,10)*5]; 	% rozsah prvkov v retazci

% MAIN CYCLE
Pop=genrpop(lpop,Space);                % generovanie n- n8hodnych retazcov 
Fit=testfn2s(Pop);                      % vypocet Rastrigin funkcie
[minFit,indx]=min(Fit);                 % najlepsi retazec
minRet=Pop(indx,:);
grafFit=zeros(1,numcykle);
for i=1:numcykle
    Pop=genrpop(lpop,Space);                % generovanie n- n8hodnych retazcov 

    Fit=testfn2s(Pop);	
    [minFitnew,indx]=min(Fit);
    if minFitnew<minFit
        minFit=minFitnew;
        minRet=Pop(indx,:);
    end
    grafFit(i)=minFit;
end

figure
plot(grafFit,'m');      % vykreslenie priebehu hladania
hold on;
xlabel('Cykly');
ylabel('F(x)')

disp('Riesenie: ')
minRet